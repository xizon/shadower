****** Copyright ******

This theme item is entirely licensed under the General Public License(GPL). 



****** Changelog ******

= 2.3 =

March 19, 2017

* Optimized admin panel.
* Upgraded shortcodes plugin.



= 2.2 =

March 15, 2017

* Compatible with low version PHP (5.3+)
* Fixed some minor errors in the low version of PHP.
* Optimized mobile navigation.



= 2.1 =

February 18, 2017

* Optimized for slideshow.
* Optimized for gallery post type.


= 2.0 =

December 28, 2016

* Optimized for shortcodes.
* Optimized for slideshow.
* Improved the running speed.
* WordPress 4.7 compatible.


= 1.5 =

October 17, 2016

* Optimized for tablet display.



= 1.4 =

September 22, 2016


* Fix: Fixed some bugs.


= 1.3 =

September 21, 2016

* New: Supports online update.
* Fix: Updated some stylesheet.



= 1.2 =

September 20, 2016

* OPTIMIZE: Optimized for theme customization.
* Fix: Updated some stylesheet.



= 1.0 =

September 8, 2016

* Initial version.
