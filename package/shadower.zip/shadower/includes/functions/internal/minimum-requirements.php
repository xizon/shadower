<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}


if( !function_exists( 'shadower_minimum_requirements' ) ) {
	add_action( 'admin_footer', 'shadower_minimum_requirements' );
	add_action( 'wp_head', 'shadower_minimum_requirements' );
	function shadower_minimum_requirements() {

		//Theme requires at least the PHP 5.3+
		if ( version_compare( PHP_VERSION, '5.3.0' ) < 0 ) {
			echo "<script>alert( '".esc_html__( 'You\'re runing WordPress on outdated PHP version. Please contact your hosting company and updgrade PHP to 5.3 or above.', 'shadower' )."' );</script>";
		}

	}	
}


