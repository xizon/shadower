<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}


if( !function_exists( 'shadower_wp_kses' ) ) {
	function shadower_wp_kses( $html ){
		
		$allowed_tags = wp_kses_allowed_html( 'post' );
		return wp_kses( $html, $allowed_tags );

	}
}


if( !function_exists( 'shadower_filter_allowed_html' ) ) {
	
	add_filter( 'wp_kses_allowed_html', 'shadower_filter_allowed_html', 10, 2 );
	function shadower_filter_allowed_html($allowed, $context){
	    
		if ( is_array( $context ) ) {
			return $allowed;
		}
	 
		if ( $context === 'post' ) {
			
			$allowed[ 'time' ] [ 'datetime' ] = true;
			$allowed[ 'div' ] [ 'data-parallax' ] = true;
			$allowed[ 'div' ] [ 'data-percent' ] = true;
			$allowed[ 'div' ] [ 'data-linewidth' ] = true;
			$allowed[ 'div' ] [ 'data-trackcolor' ] = true;
			$allowed[ 'div' ] [ 'data-barcolor' ] = true;
			$allowed[ 'div' ] [ 'data-units' ] = true;
			$allowed[ 'div' ] [ 'data-size' ] = true;
			$allowed[ 'div' ] [ 'data-icon' ] = true;
			$allowed[ 'div' ] [ 'data-tcolor' ] = true;
			$allowed[ 'div' ] [ 'data-effect' ] = true;
			$allowed[ 'div' ] [ 'data-classprefix' ] = true;
			$allowed[ 'div' ] [ 'data-filter-id' ] = true;
			$allowed[ 'div' ] [ 'data-groups' ] = true;
			$allowed[ 'div' ] [ 'data-id' ] = true;
			$allowed[ 'div' ] [ 'data-show-type' ] = true;
			$allowed[ 'div' ] [ 'data-speed' ] = true;
			$allowed[ 'div' ] [ 'data-image-src' ] = true;
			$allowed[ 'div' ] [ 'data-height' ] = true;
			$allowed[ 'div' ] [ 'data-width' ] = true;
			$allowed[ 'div' ] [ 'data-skew' ] = true;
			$allowed[ 'div' ] [ 'data-uix-slideshow' ] = true;
			$allowed[ 'div' ] [ 'data-prefix' ] = true;
			$allowed[ 'div' ] [ 'data-loop' ] = true;
			$allowed[ 'div' ] [ 'data-timing' ] = true;
			$allowed[ 'div' ] [ 'data-paging' ] = true;
			$allowed[ 'div' ] [ 'data-arrows' ] = true;
			$allowed[ 'div' ] [ 'data-animation' ] = true;
			$allowed[ 'div' ] [ 'data-hover' ] = true;
			$allowed[ 'div' ] [ 'data-default-bg' ] = true;
			$allowed[ 'div' ] [ 'data-url' ] = true;
			$allowed[ 'a' ] [ 'data-group' ] = true;
			$allowed[ 'a' ] [ 'data-id' ] = true;
			$allowed[ 'a' ] [ 'data-homepage' ] = true;
			$allowed[ 'a' ] [ 'data-thumb' ] = true;
			$allowed[ 'a' ] [ 'data-thumb-alt' ] = true;
			$allowed[ 'a' ] [ 'data-thumbcaption' ] = true;
			$allowed[ 'a' ] [ 'data-archive-id' ] = true;
			$allowed[ 'a' ] [ 'data-primary-pagination' ] = true;
			$allowed[ 'a' ] [ 'data-cat-id' ] = true;
			$allowed[ 'a' ] [ 'data-tag-id' ] = true;
			$allowed[ 'a' ] [ 'data-author-id' ] = true;
			$allowed[ 'a' ] [ 'data-temp-id' ] = true;
			$allowed[ 'img' ] [ 'data-uix-portfolio-retina' ] = true;
			$allowed[ 'img' ] [ 'data-retina' ] = true;
			$allowed[ 'img' ] [ 'data-thumb' ] = true;
			$allowed[ 'img' ] [ 'data-thumb-alt' ] = true;
			$allowed[ 'img' ] [ 'data-thumbcaption' ] = true;
			$allowed[ 'object'] [ 'width' ] = true;
			$allowed[ 'object'] [ 'height' ] = true;
			$allowed[ 'object'] [ 'data' ] = true;
			$allowed[ 'object'] [ 'form' ] = true;
			$allowed[ 'object'] [ 'type' ] = true;
			$allowed[ 'object'] [ 'usemap' ] = true;
			$allowed[ 'object'] [ 'name' ] = true;
			$allowed[ 'embed'] [ 'width' ] = true;
			$allowed[ 'embed'] [ 'height' ] = true;
			$allowed[ 'embed'] [ 'src' ] = true;
			$allowed[ 'embed'] [ 'type' ] = true;
			$allowed[ 'iframe'] [ 'src' ] = true;
			$allowed[ 'iframe'] [ 'width' ] = true;
			$allowed[ 'iframe'] [ 'height' ] = true;
			$allowed[ 'iframe'] [ 'allowfullscreen' ] = true;
			$allowed[ 'iframe'] [ 'sandbox' ] = true;
			$allowed[ 'iframe'] [ 'name' ] = true;
			$allowed[ 'source'] [ 'type' ] = true;
			$allowed[ 'source'] [ 'src' ] = true;
			$allowed[ 'source'] [ 'srcset' ] = true;
			$allowed[ 'source'] [ 'media' ] = true;
			$allowed[ 'source'] [ 'sizes' ] = true;
			$allowed[ 'svg' ] [ 'class' ] = true;
			$allowed[ 'svg' ] [ 'id' ] = true;
			$allowed[ 'svg' ] [ 'aria-hidden' ] = true;
			$allowed[ 'svg' ] [ 'aria-labelledby' ] = true;
			$allowed[ 'svg' ] [ 'role' ] = true;
			$allowed[ 'svg' ] [ 'xmlns' ] = true;
			$allowed[ 'svg' ] [ 'width' ] = true;
			$allowed[ 'svg' ] [ 'height' ] = true;
			$allowed[ 'svg' ] [ 'transform' ] = true;
			$allowed[ 'svg' ] [ 'viewbox' ] = true; // <= Must be lower case!
			$allowed[ 'g' ] [ 'fill' ] = true;
			$allowed[ 'g' ] [ 'stroke' ] = true;
			$allowed[ 'g' ] [ 'stroke-width' ] = true;
			$allowed[ 'text' ] [ 'x' ] = true;
			$allowed[ 'text' ] [ 'y' ] = true;
			$allowed[ 'text' ] [ 'class' ] = true;
			$allowed[ 'path' ] [ 'class' ] = true;
			$allowed[ 'path' ] [ 'd' ] = true; 
			$allowed[ 'path' ] [ 'fill' ] = true; 
			$allowed[ 'circle' ] [ 'class' ] = true; 
			$allowed[ 'circle' ] [ 'cx' ] = true; 
			$allowed[ 'circle' ] [ 'cy' ] = true; 
			$allowed[ 'circle' ] [ 'fill' ] = true; 
			$allowed[ 'circle' ] [ 'r' ] = true;
			$allowed[ 'circle' ] [ 'stroke' ] = true;
			$allowed[ 'circle' ] [ 'stroke-width' ] = true;
			$allowed[ 'rect' ] [ 'class' ] = true; 
			$allowed[ 'rect' ] [ 'x' ] = true; 
			$allowed[ 'rect' ] [ 'y' ] = true; 
			$allowed[ 'rect' ] [ 'rx' ] = true; 
			$allowed[ 'rect' ] [ 'ry' ] = true; 
			$allowed[ 'rect' ] [ 'width' ] = true; 
			$allowed[ 'rect' ] [ 'height' ] = true;
			$allowed[ 'defs' ] = true;
			$allowed[ 'linearGradient' ] [ 'id' ] = true;
			$allowed[ 'radialGradient' ] [ 'id' ] = true;
			$allowed[ 'radialGradient' ] [ 'spreadMethod' ] = true;
			$allowed[ 'radialGradient' ] [ 'cx' ] = true;
			$allowed[ 'radialGradient' ] [ 'cy' ] = true;
			$allowed[ 'radialGradient' ] [ 'r' ] = true;
			$allowed[ 'radialGradient' ] [ 'fx' ] = true;
			$allowed[ 'radialGradient' ] [ 'fy' ] = true;
			$allowed[ 'radialGradient' ] [ 'fr' ] = true;
			$allowed[ 'stop' ] [ 'offset' ] = true;
			$allowed[ 'stop' ] [ 'stop-color' ] = true;

	
			
		}
	 
		return $allowed;
	}

}

 